# Q2.Dataframe using a dictionary
import pandas as pd
student = {
    "Roll_No": [1, 2, 3, 4],
    "Name": ["Om", "Rahul", "Sarth", "Arshad"],
    "Marks": [85, 78, 92, 88]
}
df = pd.DataFrame(student)
print(df)












