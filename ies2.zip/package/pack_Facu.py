class Faculty:
    def faculty_info(self)
        print("Faculty Name: A.V.Patil")
        print("Subject: Data structure")
        print("Depertment: CSE")