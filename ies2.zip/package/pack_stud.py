class Student:
    def student_info(self):
     print("Student Name: Om Kamate")
     print("Roll No: 24")
     print("Branch: CSE")
