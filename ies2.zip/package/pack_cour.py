class Course:
    def course_info(self)
        print("Course Name: Data structure")
        print("Course duration: 6 month")
        print("Course fee: 1999")