from college.student import Student
from college.faculty import Faculty
from college.course import Course

s = Student()
f = Faculty()
c = Course()

print("Student Information")
s.student_info()
print("Faculty Information")
f.faculty_info()
print("Course Information ")
c.course_info()